export interface Product {
  id: string;
  name: string;
  category: 'doces' | 'bolos' | 'salgados' | 'mousses' | 'kits';
  categoryLabel: string;
  description: string;
  price: number;
  priceUnit?: string; // e.g. '/kg' or undefined for unit
  image: string;
  isFeatured?: boolean;
  highlightBadge?: string;
  contents?: string[]; // for Kits Festas
}

export interface CartItem {
  product: Product;
  quantity: number;
  notes?: string;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  address: string;
  neighborhood: string;
  city: string;
  deliveryType: 'delivery' | 'pickup';
  paymentMethod: 'pix' | 'cartao_entrega' | 'dinheiro';
  changeFor?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatar: string;
  comment: string;
  rating: number;
  occasion?: string;
  orderHighlight?: string;
}
