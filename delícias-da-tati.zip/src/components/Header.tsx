import React, { useState } from 'react';
import { 
  Search, 
  ShoppingBag, 
  User, 
  Menu, 
  X, 
  Heart, 
  Phone,
  Cake, 
  Clock, 
  MapPin,
  Sparkles
} from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

interface HeaderProps {
  cartCount: number;
  cartTotal: number;
  favoritesCount: number;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenCart: () => void;
  onOpenAccount: () => void;
  onToggleFavoritesOnly: () => void;
  showOnlyFavorites: boolean;
  onNavigateToCategory: (category: string) => void;
  activeCategory: string;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  cartTotal,
  favoritesCount,
  searchQuery,
  onSearchChange,
  onOpenCart,
  onOpenAccount,
  onToggleFavoritesOnly,
  showOnlyFavorites,
  onNavigateToCategory,
  activeCategory,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { id: 'inicio', label: 'Início', target: 'hero' },
    { id: 'doces', label: 'Doces de Festa', target: 'section-doces' },
    { id: 'bolos', label: 'Bolos Confeitados', target: 'section-bolos' },
    { id: 'salgados', label: 'Salgados de Festa', target: 'section-salgados' },
    { id: 'mousses', label: 'Mousses & Sobremesas', target: 'section-mousses' },
    { id: 'kits', label: 'Kits Festas', target: 'section-kits' },
    { id: 'personalizado', label: 'Encomendas Especiais', target: 'personalizado' },
    { id: 'sobre', label: 'Sobre Nós', target: 'section-sobre' },
    { id: 'contato', label: 'Contato', target: 'section-contato' },
  ];

  const handleMenuClick = (item: typeof menuItems[0]) => {
    setMobileMenuOpen(false);
    if (item.id === 'inicio') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.getElementById(item.target);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    } else {
      onNavigateToCategory(item.id);
    }
  };

  const formattedTotal = cartTotal.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  return (
    <header className="sticky top-0 z-40 bg-[#FFFDF9]/95 backdrop-blur-md border-b border-[#EEDDD4] shadow-xs">
      {/* Top microbar with delivery notice & quick contact */}
      <div className="bg-[#3D1E16] text-[#F9EBE6] text-xs py-1.5 px-4 hidden md:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <span className="flex items-center gap-1.5 text-amber-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Entregas rápidas em Tamoios e região de Cabo Frio/RJ</span>
            </span>
            <span className="flex items-center gap-1.5 text-[#E7C7BE]">
              <Clock className="w-3.5 h-3.5" />
              <span>Seg a Sáb até 22h | Dom 8h às 18h</span>
            </span>
          </div>
          <div className="flex items-center gap-4 text-[#F3D7CE]">
            <a
              href={`https://wa.me/${STORE_CONFIG.whatsappRaw}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-amber-200 transition-colors flex items-center gap-1 font-medium"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>{STORE_CONFIG.whatsappDisplay}</span>
            </a>
            <span className="text-[#845347]">|</span>
            <span className="flex items-center gap-1 text-[#E7C7BE]">
              <MapPin className="w-3.5 h-3.5" />
              <span>Rua do Sol, Tamoios</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          
          {/* Logo & Brand Identity */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2.5 text-left group shrink-0 cursor-pointer focus:outline-none"
            aria-label="Ir para o início"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-[#8C384F] to-[#4A1E14] text-amber-100 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-200 border-2 border-amber-300/40">
              <Cake className="w-5 h-5 sm:w-6 sm:h-6 text-amber-200" />
            </div>
            <div>
              <span className="font-serif-title text-xl sm:text-2xl font-bold tracking-tight text-[#3A1B13] block leading-tight group-hover:text-[#9A354E] transition-colors">
                Delícias da Tati
              </span>
              <span className="text-[11px] sm:text-xs text-[#8A5A4A] font-medium tracking-wide block">
                {STORE_CONFIG.slogan}
              </span>
            </div>
          </button>

          {/* Search Bar - Center */}
          <div className="flex-1 max-w-md mx-2 hidden sm:block relative">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="O que você está procurando?"
                className="w-full bg-[#F7EFE9] text-[#2C1810] placeholder-[#9E7D72] text-sm rounded-full pl-10 pr-9 py-2.5 border border-[#DFCCC2] focus:border-[#B24C63] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#B24C63]/20 transition-all shadow-inner"
              />
              <Search className="w-4 h-4 text-[#8C6255] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 p-0.5 rounded-full"
                  aria-label="Limpar pesquisa"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons: WhatsApp, Favorites, Account, Cart */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Direct WhatsApp Call */}
            <a
              href={`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent('Olá! Gostaria de fazer um pedido na Delícias da Tati.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:flex items-center gap-2 bg-[#E8F8F0] hover:bg-[#D5F2E3] text-[#0D6832] border border-[#B6E7CD] px-3.5 py-2 rounded-full text-xs font-semibold tracking-wide transition-all shadow-xs active:scale-95"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>Peça pelo WhatsApp</span>
            </a>

            {/* Favorites Filter Button */}
            <button
              onClick={onToggleFavoritesOnly}
              className={`relative p-2.5 rounded-full border transition-all active:scale-95 cursor-pointer ${
                showOnlyFavorites
                  ? 'bg-[#A83852] text-white border-[#A83852] shadow-sm'
                  : 'bg-[#F9EFE9] text-[#4A2016] border-[#E2CEBF] hover:border-[#A83852] hover:text-[#A83852]'
              }`}
              title={showOnlyFavorites ? 'Ver todos os produtos' : 'Ver meus favoritos'}
              aria-label="Meus favoritos"
            >
              <Heart className={`w-4 h-4 sm:w-5 sm:h-5 ${showOnlyFavorites ? 'fill-white' : favoritesCount > 0 ? 'fill-[#A83852] text-[#A83852]' : ''}`} />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#A83852] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Minha Conta */}
            <button
              onClick={onOpenAccount}
              className="hidden md:flex items-center gap-1.5 text-xs font-medium text-[#462319] hover:text-[#A83852] bg-[#F9EFE9] hover:bg-[#F2DFD5] border border-[#E2CEBF] px-3 py-2 rounded-full transition-colors cursor-pointer"
            >
              <User className="w-4 h-4 text-[#8C384F]" />
              <span>Minha Conta</span>
            </button>

            {/* Cart Button with Total */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2.5 bg-gradient-to-r from-[#8C384F] to-[#71283B] hover:from-[#7C3044] hover:to-[#5E2030] text-white px-3.5 sm:px-4 py-2 rounded-full shadow-md hover:shadow-lg transition-all active:scale-95 cursor-pointer border border-[#A64A62]"
              aria-label={`Abrir carrinho com ${cartCount} itens. Total ${formattedTotal}`}
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-[#30130B] font-extrabold text-[10px] sm:text-[11px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="text-left leading-tight hidden xs:block">
                <span className="text-[10px] uppercase font-semibold text-rose-200 tracking-wider block">
                  Carrinho
                </span>
                <span className="text-xs sm:text-sm font-bold text-white block">
                  {formattedTotal}
                </span>
              </div>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#3D1E16] hover:bg-[#F2DFD5] md:hidden transition-colors cursor-pointer"
              aria-label="Abrir menu principal"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>
        </div>

        {/* Mobile Search input bar */}
        <div className="mt-2.5 block sm:hidden relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="O que você está procurando?"
            className="w-full bg-[#F7EFE9] text-[#2C1810] placeholder-[#9E7D72] text-sm rounded-full pl-10 pr-9 py-2 border border-[#DFCCC2] focus:border-[#B24C63] focus:bg-white focus:outline-none"
          />
          <Search className="w-4 h-4 text-[#8C6255] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Desktop Navigation Menu */}
      <nav className="hidden md:block bg-[#FAF2EB] border-t border-[#EEDDD4]/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <ul className="flex items-center justify-center space-x-1 lg:space-x-2 py-2 text-xs lg:text-sm font-medium text-[#462319]">
            {menuItems.map((item) => {
              const isActive = activeCategory === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => handleMenuClick(item)}
                    className={`px-3 py-1.5 rounded-full transition-all cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-[#8C384F] text-white shadow-xs font-semibold'
                        : 'hover:text-[#8C384F] hover:bg-[#EFE2D8]'
                    }`}
                  >
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FFFDF9] border-t border-[#E8D4C8] shadow-xl px-4 py-4 space-y-2 animate-fadeIn">
          <div className="text-xs font-semibold text-[#8C384F] uppercase tracking-wider px-3 pb-1 border-b border-[#F0DFD5]">
            Navegação do Cardápio
          </div>
          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleMenuClick(item)}
                className="text-left px-3 py-2 text-sm rounded-lg text-[#3E1F17] hover:bg-[#F7EBE3] hover:text-[#8C384F] transition-colors font-medium flex items-center justify-between"
              >
                <span>{item.label}</span>
                <span className="text-xs text-[#9C7063]">→</span>
              </button>
            ))}
          </div>
          
          <div className="pt-3 mt-2 border-t border-[#EEDDD4] flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAccount();
              }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#F7EFE9] text-[#462319] rounded-xl font-medium text-sm border border-[#E2CEBF]"
            >
              <User className="w-4 h-4 text-[#8C384F]" />
              <span>Minha Conta / Meus Dados de Entrega</span>
            </button>
            <a
              href={`https://wa.me/${STORE_CONFIG.whatsappRaw}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-[#1EA553] text-white rounded-xl font-semibold text-sm shadow-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Falar no WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
