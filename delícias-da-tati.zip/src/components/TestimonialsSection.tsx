import React, { useRef, useState, useEffect } from 'react';
import { Star, Quote, ChevronLeft, ChevronRight, CheckCircle2, Cake, Sparkles } from 'lucide-react';
import { TESTIMONIALS } from '../data/products';

export const TestimonialsSection: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 20);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 20);

      // Estimate current active page index for Netflix dashes
      const totalPages = Math.max(1, Math.ceil((scrollWidth - clientWidth) / 360) + 1);
      const progress = scrollLeft / (scrollWidth - clientWidth || 1);
      const current = Math.min(totalPages - 1, Math.round(progress * (totalPages - 1)));
      setActiveIndex(current);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });
    window.addEventListener('resize', checkScroll);
    return () => {
      el.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, []);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const cardWidth = 360;
      const scrollAmount = direction === 'left' ? -cardWidth * 1.5 : cardWidth * 1.5;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section id="depoimentos" className="py-14 sm:py-20 bg-[#160A06] text-white border-y border-[#33170E] relative overflow-hidden">
      {/* Subtle atmospheric glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#8C384F]/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header: Netflix Style */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6 sm:mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-sm bg-[#E50914] text-white text-[10px] font-black tracking-widest uppercase shadow-xs">
                <Sparkles className="w-3 h-3" />
                TOP AVALIAÇÕES
              </span>
              <span className="text-xs text-amber-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                ★ 5.0 estrelas • Mais de 500 festas atendidas
              </span>
            </div>
            <h2 className="font-serif-title text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              O que nossos clientes dizem
            </h2>
            <p className="text-xs sm:text-sm text-[#CDB2A6] mt-1 max-w-xl">
              Depoimentos reais de quem celebrou aniversários, batizados e momentos especiais com as Delícias da Tati.
            </p>
          </div>

          {/* Netflix Page Indicator Bars + Navigation Buttons */}
          <div className="flex items-center gap-4">
            {/* Indicator Bars */}
            <div className="hidden md:flex items-center gap-1.5">
              {[0, 1, 2, 3].map((barIdx) => (
                <div
                  key={barIdx}
                  className={`h-1 rounded-full transition-all duration-300 ${
                    activeIndex === barIdx
                      ? 'w-6 bg-white shadow-xs'
                      : 'w-3 bg-white/20'
                  }`}
                />
              ))}
            </div>

            {/* Desktop Arrows */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleScroll('left')}
                disabled={!canScrollLeft}
                className={`w-9 h-9 rounded-full border border-white/20 bg-white/10 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer ${
                  canScrollLeft
                    ? 'hover:bg-white/20 text-white hover:border-white/40 active:scale-95'
                    : 'opacity-30 cursor-not-allowed text-white/50'
                }`}
                aria-label="Ver depoimentos anteriores"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleScroll('right')}
                disabled={!canScrollRight}
                className={`w-9 h-9 rounded-full border border-white/20 bg-white/10 backdrop-blur-md flex items-center justify-center transition-all cursor-pointer ${
                  canScrollRight
                    ? 'hover:bg-white/20 text-white hover:border-white/40 active:scale-95'
                    : 'opacity-30 cursor-not-allowed text-white/50'
                }`}
                aria-label="Ver próximos depoimentos"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Carousel Row with Netflix-Style Hover Paddles */}
        <div className="relative group">
          
          {/* Netflix Left Edge Paddle */}
          <button
            onClick={() => handleScroll('left')}
            className={`hidden sm:flex absolute left-0 top-0 bottom-4 z-20 w-12 items-center justify-center bg-gradient-to-r from-[#160A06]/95 via-[#160A06]/60 to-transparent text-white transition-opacity duration-300 cursor-pointer ${
              canScrollLeft ? 'opacity-0 group-hover:opacity-100' : 'pointer-events-none opacity-0'
            }`}
            aria-label="Rolar depoimentos para esquerda"
          >
            <div className="w-9 h-9 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center hover:scale-110 hover:bg-black/80 transition-all shadow-xl">
              <ChevronLeft className="w-5 h-5" />
            </div>
          </button>

          {/* Netflix Right Edge Paddle */}
          <button
            onClick={() => handleScroll('right')}
            className={`hidden sm:flex absolute right-0 top-0 bottom-4 z-20 w-12 items-center justify-center bg-gradient-to-l from-[#160A06]/95 via-[#160A06]/60 to-transparent text-white transition-opacity duration-300 cursor-pointer ${
              canScrollRight ? 'opacity-0 group-hover:opacity-100' : 'pointer-events-none opacity-0'
            }`}
            aria-label="Rolar depoimentos para direita"
          >
            <div className="w-9 h-9 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center hover:scale-110 hover:bg-black/80 transition-all shadow-xl">
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          {/* Scrollable Track */}
          <div
            ref={scrollRef}
            className="flex gap-4 sm:gap-6 overflow-x-auto pb-6 pt-2 no-scrollbar snap-x snap-mandatory scroll-smooth"
          >
            {TESTIMONIALS.map((t, idx) => (
              <div
                key={t.id}
                className="min-w-[300px] sm:min-w-[350px] max-w-[360px] shrink-0 snap-start"
              >
                <div className="h-full bg-gradient-to-b from-[#23120B] to-[#1C0E08] border border-[#3B1E13] hover:border-[#8C384F] rounded-2xl p-5 sm:p-6 shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col justify-between transform hover:-translate-y-1 group/card relative overflow-hidden">
                  
                  {/* Subtle top ambient bar */}
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-[#8C384F] to-rose-600 opacity-80" />

                  <div>
                    {/* Top Row: Occasion badge & Stars */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      {t.occasion ? (
                        <span className="inline-block text-[11px] font-semibold text-amber-300/90 bg-amber-400/10 border border-amber-400/20 px-2.5 py-0.5 rounded-full">
                          {t.occasion}
                        </span>
                      ) : (
                        <span className="inline-block text-[11px] font-semibold text-rose-300/90 bg-rose-400/10 border border-rose-400/20 px-2.5 py-0.5 rounded-full">
                          ★ Recomendado
                        </span>
                      )}

                      {/* 5 Stars */}
                      <div className="flex items-center gap-0.5 text-amber-400">
                        {[...Array(t.rating)].map((_, i) => (
                          <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                        ))}
                      </div>
                    </div>

                    {/* Highlight order pill if available */}
                    {t.orderHighlight && (
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-[#D5A795] mb-3 bg-[#2D160D] px-2.5 py-1 rounded-lg border border-[#432316]">
                        <Cake className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span className="truncate">Pediu: <strong className="text-white font-semibold">{t.orderHighlight}</strong></span>
                      </div>
                    )}

                    {/* Quote text */}
                    <div className="relative mb-5">
                      <Quote className="w-5 h-5 text-rose-400/30 absolute -top-1 -left-1 transform -scale-x-100" />
                      <p className="text-xs sm:text-sm text-[#E6D0C5] leading-relaxed italic pl-5 line-clamp-4">
                        "{t.comment}"
                      </p>
                    </div>
                  </div>

                  {/* Customer Card Footer: Avatar + Verified Customer */}
                  <div className="pt-3 border-t border-[#351A10] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={t.avatar}
                          alt={t.name}
                          onError={(e) => {
                            const target = e.currentTarget;
                            target.onerror = null;
                            target.src = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80';
                          }}
                          className="w-10 h-10 rounded-full object-cover border-2 border-amber-400/40 group-hover/card:border-amber-400 transition-colors"
                        />
                        <div className="absolute -bottom-1 -right-1 bg-[#160A06] rounded-full p-0.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/20" />
                        </div>
                      </div>
                      <div>
                        <h4 className="font-serif-title font-bold text-sm text-white leading-tight">
                          {t.name}
                        </h4>
                        <span className="text-[11px] text-[#A67E71] block">
                          {t.role}
                        </span>
                      </div>
                    </div>

                    <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full shrink-0">
                      Verificado
                    </span>
                  </div>

                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Mobile Swipe Hint */}
        <div className="flex sm:hidden items-center justify-center gap-1.5 text-xs text-[#9E7365] mt-2">
          <span>← Deslize para ver mais depoimentos →</span>
        </div>

      </div>
    </section>
  );
};
