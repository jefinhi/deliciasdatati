import React from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, MessageCircle, Truck, Store } from 'lucide-react';
import { CartItem } from '../types';
import { STORE_CONFIG } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  onSendDirectWhatsApp: () => void;
  deliveryType: 'delivery' | 'pickup';
  onDeliveryTypeChange: (type: 'delivery' | 'pickup') => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  onSendDirectWhatsApp,
  deliveryType,
  onDeliveryTypeChange,
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const deliveryFee = deliveryType === 'pickup' ? 0 : subtotal >= STORE_CONFIG.freeDeliveryThreshold ? 0 : STORE_CONFIG.deliveryFee;
  const total = subtotal + deliveryFee;

  const formatCurrency = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-300"
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FFFDF9] shadow-2xl flex flex-col justify-between border-l border-[#E2CEBF]">
          
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-[#EEDDD4] bg-[#FAF2EB] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#8C384F] text-white flex items-center justify-center shadow-xs">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-serif-title font-bold text-lg text-[#30150D]">
                  Seu Carrinho
                </h2>
                <span className="text-xs text-[#8A5A4A]">
                  {cartItems.length} {cartItems.length === 1 ? 'item selecionado' : 'itens selecionados'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {cartItems.length > 0 && (
                <button
                  onClick={onClearCart}
                  className="text-xs text-[#9B384A] hover:text-red-700 font-medium px-2 py-1 rounded-md hover:bg-rose-50 cursor-pointer transition-colors"
                >
                  Limpar
                </button>
              )}
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-white text-gray-500 hover:text-gray-800 hover:bg-gray-100 flex items-center justify-center transition-colors cursor-pointer border border-[#DFCCC2]"
                aria-label="Fechar carrinho"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Drawer Body / Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-[#F1E5DC]">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 px-4">
                <div className="w-20 h-20 rounded-full bg-[#F6ECE4] text-[#8C384F] flex items-center justify-center mb-4 shadow-inner">
                  <ShoppingBag className="w-9 h-9" />
                </div>
                <h3 className="font-serif-title font-bold text-xl text-[#361910] mb-2">
                  Seu carrinho está vazio
                </h3>
                <p className="text-xs sm:text-sm text-[#7D5347] max-w-xs mb-6">
                  Que tal experimentar um dos nossos bolos confeitados ou doces gourmet artesanais?
                </p>
                <button
                  onClick={onClose}
                  className="bg-[#8C384F] hover:bg-[#72273B] text-white font-semibold text-sm px-6 py-2.5 rounded-full transition-all shadow-md cursor-pointer"
                >
                  Ver Cardápio
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Entrega vs Retirada Selector */}
                <div className="bg-[#FAF3EE] p-2.5 rounded-xl border border-[#E9DACF] mb-3">
                  <div className="text-[11px] font-bold text-[#8C384F] uppercase mb-1.5 flex items-center justify-between">
                    <span>Opção de Recebimento</span>
                    {subtotal >= STORE_CONFIG.freeDeliveryThreshold && (
                      <span className="text-emerald-700 font-bold lowercase">Entrega grátis ativa!</span>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onDeliveryTypeChange('delivery')}
                      className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        deliveryType === 'delivery'
                          ? 'bg-white text-[#8C384F] shadow-xs border border-[#8C384F]/30'
                          : 'text-[#6A473D] hover:bg-white/60'
                      }`}
                    >
                      <Truck className="w-3.5 h-3.5" />
                      <span>Entrega (+R$ 5,00)</span>
                    </button>
                    <button
                      onClick={() => onDeliveryTypeChange('pickup')}
                      className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        deliveryType === 'pickup'
                          ? 'bg-white text-[#8C384F] shadow-xs border border-[#8C384F]/30'
                          : 'text-[#6A473D] hover:bg-white/60'
                      }`}
                    >
                      <Store className="w-3.5 h-3.5" />
                      <span>Retirada (Grátis)</span>
                    </button>
                  </div>
                </div>

                {/* Items List */}
                {cartItems.map((item) => {
                  const itemSubtotal = item.product.price * item.quantity;
                  return (
                    <div key={item.product.id} className="pt-3 pb-3 flex gap-3 items-center">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        onError={(e) => {
                          const target = e.currentTarget;
                          target.onerror = null;
                          target.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=400&q=80';
                        }}
                        className="w-16 h-16 sm:w-18 sm:h-18 rounded-xl object-cover border border-[#EADBCE] shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-serif-title font-bold text-sm text-[#2E140C] truncate">
                          {item.product.name}
                        </h4>
                        <span className="text-xs text-[#7A5044] block">
                          {formatCurrency(item.product.price)} {item.product.priceUnit || ''}
                        </span>
                        
                        {/* Quantity controls */}
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center border border-[#DECBC0] rounded-lg bg-white overflow-hidden shadow-xs">
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                              className="w-7 h-7 flex items-center justify-center text-[#55271B] hover:bg-[#F6ECE4] transition-colors cursor-pointer"
                              aria-label="Diminuir quantidade"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-8 text-center text-xs font-bold text-[#2A1109]">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                              className="w-7 h-7 flex items-center justify-center text-[#55271B] hover:bg-[#F6ECE4] transition-colors cursor-pointer"
                              aria-label="Aumentar quantidade"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() => onRemoveItem(item.product.id)}
                            className="text-[#A2384C] hover:text-red-700 p-1.5 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                            aria-label={`Remover ${item.product.name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="text-[10px] text-[#936D61] block">Subtotal</span>
                        <span className="text-sm font-bold text-[#3A170F]">
                          {formatCurrency(itemSubtotal)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Drawer Footer & Checkout Buttons */}
          {cartItems.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-[#EEDDD4] bg-[#FAF2EB] space-y-3">
              <div className="space-y-1.5 text-xs sm:text-sm text-[#664338]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-[#2C130B]">{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxa de Entrega ({deliveryType === 'delivery' ? 'Tamoios' : 'Retirada'})</span>
                  <span className="font-semibold text-[#2C130B]">
                    {deliveryFee === 0 ? 'Grátis' : formatCurrency(deliveryFee)}
                  </span>
                </div>
                <div className="flex justify-between text-base sm:text-lg font-bold text-[#2A1008] pt-2 border-t border-[#DECBC0]">
                  <span>Total</span>
                  <span className="text-[#8C384F]">{formatCurrency(total)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-1 gap-2 pt-2">
                <button
                  onClick={onProceedToCheckout}
                  className="w-full bg-gradient-to-r from-[#8C384F] to-[#71283B] hover:from-[#9B3D55] hover:to-[#812B41] text-white font-bold py-3 px-4 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 text-sm cursor-pointer active:scale-98"
                >
                  <span>FINALIZAR PEDIDO</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onSendDirectWhatsApp}
                  className="w-full bg-[#128C45] hover:bg-[#15A14F] text-white font-bold py-2.5 px-4 rounded-xl shadow-xs transition-all duration-200 flex items-center justify-center gap-2 text-xs sm:text-sm cursor-pointer active:scale-98 border border-emerald-600/30"
                >
                  <MessageCircle className="w-4 h-4 fill-white" />
                  <span>ENVIAR PELO WHATSAPP</span>
                </button>
              </div>

              <div className="text-center pt-1">
                <span className="text-[11px] text-[#865E51]">
                  WhatsApp comercial oficial: {STORE_CONFIG.whatsappDisplay}
                </span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
