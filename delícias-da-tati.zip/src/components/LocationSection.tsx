import React, { useMemo } from 'react';
import { MapPin, Clock, Phone, Navigation, ExternalLink, ShieldCheck } from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

export const LocationSection: React.FC = () => {
  // Calculate if currently open based on Brazilian local time (BRT / UTC-3)
  const isOpenNow = useMemo(() => {
    const now = new Date();
    // Convert to BRT (UTC-3)
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const brt = new Date(utc - (3 * 3600000));
    const day = brt.getDay(); // 0 is Sunday, 6 is Saturday
    const hour = brt.getHours();

    if (day === 0) {
      // Sunday: 8h to 18h
      return hour >= 8 && hour < 18;
    } else {
      // Mon-Sat: until 22h (e.g. 8h to 22h)
      return hour >= 8 && hour < 22;
    }
  }, []);

  return (
    <section id="section-contato" className="py-14 sm:py-18 bg-[#FAF2EB] border-b border-[#E8D4C8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs uppercase font-extrabold tracking-widest text-[#8C384F] block mb-1">
            Localização & Contato
          </span>
          <h2 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#32160E]">
            Venha nos Conhecer ou Peça Delivery
          </h2>
          <p className="text-xs sm:text-sm text-[#7D5347] mt-1">
            Preparamos tudo com muito carinho para retirada no balcão ou entrega rápida na sua porta.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Card 1: Address & Directions */}
          <div className="bg-white rounded-2xl p-6 border border-[#EADBCE] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#FAF0E8] text-[#8C384F] flex items-center justify-center mb-4 border border-[#E8D4C8]">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="font-serif-title font-bold text-lg text-[#32160E] mb-2">
                Nosso Endereço
              </h3>
              <p className="text-sm font-semibold text-[#542F25] mb-1">
                {STORE_CONFIG.address}
              </p>
              <p className="text-xs text-[#7F5649] leading-relaxed mb-6">
                Região central de Tamoios, 2º Distrito de Cabo Frio. Atendemos todo o distrito e bairros vizinhos com entrega rápida.
              </p>
            </div>

            <a
              href={STORE_CONFIG.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-[#8C384F] hover:bg-[#72273B] text-white font-bold py-3 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 text-xs sm:text-sm cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
              <span>COMO CHEGAR (GOOGLE MAPS)</span>
            </a>
          </div>

          {/* Card 2: Operating Hours with Live Badge */}
          <div className="bg-white rounded-2xl p-6 border border-[#EADBCE] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-[#FAF0E8] text-[#8C384F] flex items-center justify-center mb-4 border border-[#E8D4C8]">
                <Clock className="w-5 h-5" />
              </div>

              <div className="flex items-center justify-between mb-2">
                <h3 className="font-serif-title font-bold text-lg text-[#32160E]">
                  Horário de Atendimento
                </h3>
                {isOpenNow ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    Aberto agora
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    Fechado no momento
                  </span>
                )}
              </div>

              <div className="space-y-2.5 text-xs sm:text-sm text-[#542F25] mt-4">
                <div className="p-2.5 bg-[#FAF4EE] rounded-xl border border-[#E8D9CD]">
                  <span className="font-bold block text-[#8C384F]">Segunda a Sábado</span>
                  <span className="text-xs text-[#6C473C]">{STORE_CONFIG.openingHoursWeekday}</span>
                </div>
                <div className="p-2.5 bg-[#FAF4EE] rounded-xl border border-[#E8D9CD]">
                  <span className="font-bold block text-[#8C384F]">Domingo</span>
                  <span className="text-xs text-[#6C473C]">{STORE_CONFIG.openingHoursSunday}</span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-[#865E51] mt-4 pt-3 border-t border-[#F0E1D6]">
              * Encomendas de bolos e kits festas podem ser agendadas com antecedência pelo WhatsApp a qualquer hora.
            </p>
          </div>

          {/* Card 3: WhatsApp & Orders Contact */}
          <div className="bg-white rounded-2xl p-6 border border-[#EADBCE] shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-[#0F6F37] flex items-center justify-center mb-4 border border-emerald-200">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="font-serif-title font-bold text-lg text-[#32160E] mb-2">
                Atendimento Rápido
              </h3>
              <p className="text-base font-extrabold text-emerald-800 mb-1">
                {STORE_CONFIG.whatsappDisplay}
              </p>
              <p className="text-xs text-[#7F5649] leading-relaxed mb-6">
                Tire dúvidas sobre ingredientes, reserve seu bolo favorito ou faça encomendas especiais diretamente com nossa equipe.
              </p>
            </div>

            <a
              href={`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent('Olá! Gostaria de falar com a Delícias da Tati sobre encomendas e cardápio.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-[#128C45] hover:bg-[#15A14F] text-white font-bold py-3 px-4 rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 text-xs sm:text-sm cursor-pointer border border-emerald-600/30"
            >
              <Phone className="w-4 h-4" />
              <span>CHAMAR NO WHATSAPP</span>
            </a>
          </div>

        </div>

      </div>
    </section>
  );
};
