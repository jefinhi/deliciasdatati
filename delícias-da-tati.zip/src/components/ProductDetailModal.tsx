import React, { useState } from 'react';
import { X, Heart, Plus, Minus, ShoppingBag, MessageCircle, Check, Sparkles, ShieldCheck } from 'lucide-react';
import { Product } from '../types';
import { STORE_CONFIG } from '../data/products';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [addedAnimation, setAddedAnimation] = useState(false);

  if (!isOpen || !product) return null;

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      onClose();
    }, 900);
  };

  const handleWhatsApp = () => {
    const formattedTotal = (product.price * quantity).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
    const message = encodeURIComponent(
      `Olá Tati! Gostaria de pedir ${quantity}x "${product.name}" (${formattedTotal}) diretamente pelo cardápio.`
    );
    window.open(`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${message}`, '_blank');
  };

  const formattedPrice = product.price.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  const totalCalculated = (product.price * quantity).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#FFFDF9] rounded-2xl max-w-2xl w-full shadow-2xl border border-[#E0CFBF] overflow-hidden flex flex-col md:flex-row relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-white/90 text-gray-700 hover:bg-white flex items-center justify-center shadow-md cursor-pointer border border-[#DECBC0]"
          aria-label="Fechar detalhes"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Product Image */}
        <div className="md:w-1/2 relative min-h-[260px] md:min-h-full bg-[#F6ECE4]">
          <img
            src={product.image}
            alt={product.name}
            onError={(e) => {
              const target = e.currentTarget;
              target.onerror = null;
              target.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80';
            }}
            className="w-full h-full object-cover"
          />
          {product.highlightBadge && (
            <div className="absolute top-3 left-3 bg-gradient-to-r from-[#8C384F] to-[#71283B] text-white text-xs font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{product.highlightBadge}</span>
            </div>
          )}
        </div>

        {/* Product Details & Actions */}
        <div className="p-5 sm:p-6 md:w-1/2 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C384F]">
                {product.categoryLabel}
              </span>
              <button
                onClick={() => onToggleFavorite(product.id)}
                className={`p-2 rounded-full border transition-all cursor-pointer ${
                  isFavorite
                    ? 'bg-rose-500 text-white border-rose-500'
                    : 'bg-white text-gray-500 border-[#DECBC0] hover:text-rose-500'
                }`}
                aria-label="Favoritar"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
              </button>
            </div>

            <h3 className="font-serif-title text-xl sm:text-2xl font-bold text-[#2A1109] mb-2 leading-tight">
              {product.name}
            </h3>

            <p className="text-xs sm:text-sm text-[#734E42] leading-relaxed mb-4">
              {product.description}
            </p>

            {/* If Kit Contents */}
            {product.contents && (
              <div className="mb-4 p-3 bg-[#FAF3EE] rounded-xl border border-[#EDE0D6]">
                <span className="text-xs font-bold text-[#8C384F] uppercase tracking-wider block mb-1.5">
                  O que está incluso neste kit:
                </span>
                <ul className="space-y-1 text-xs text-[#52332A]">
                  {product.contents.map((c, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-[#8C384F] font-bold">•</span>
                      <span>{c}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center gap-2 text-xs text-emerald-800 bg-emerald-50/70 p-2.5 rounded-lg border border-emerald-200/60 mb-5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Preparado artesanalmente com ingredientes de alta qualidade</span>
            </div>
          </div>

          <div>
            {/* Price & Quantity Selector */}
            <div className="flex items-center justify-between py-3 border-t border-b border-[#EEDDD4] mb-4">
              <div>
                <span className="text-[10px] text-[#865E51] uppercase font-bold block">Preço unitário</span>
                <span className="text-xl font-extrabold text-[#32150D]">
                  {formattedPrice}
                  {product.priceUnit && <span className="text-xs font-semibold text-[#865E51] ml-1">{product.priceUnit}</span>}
                </span>
              </div>

              {/* Quantity */}
              <div className="flex items-center border border-[#DECBC0] rounded-xl bg-white overflow-hidden shadow-xs">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-9 h-9 flex items-center justify-center text-[#55271B] hover:bg-[#F6ECE4] cursor-pointer"
                  aria-label="Diminuir"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-10 text-center font-bold text-sm text-[#2A1109]">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-9 h-9 flex items-center justify-center text-[#55271B] hover:bg-[#F6ECE4] cursor-pointer"
                  aria-label="Aumentar"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Total calculation indicator */}
            <div className="flex justify-between items-center text-xs text-[#714D41] mb-3 px-1">
              <span>Subtotal ({quantity} {quantity === 1 ? 'unidade' : 'unidades'}):</span>
              <span className="font-bold text-sm text-[#8C384F]">{totalCalculated}</span>
            </div>

            {/* Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={handleAdd}
                className={`py-3 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                  addedAnimation
                    ? 'bg-emerald-600 text-white'
                    : 'bg-[#8C384F] hover:bg-[#72273B] text-white'
                }`}
              >
                {addedAnimation ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Adicionado!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Adicionar ao Carrinho</span>
                  </>
                )}
              </button>

              <button
                onClick={handleWhatsApp}
                className="py-3 px-4 rounded-xl font-bold text-xs sm:text-sm bg-[#128C45] hover:bg-[#15A14F] text-white flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs border border-emerald-600/40"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Pedir no WhatsApp</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
