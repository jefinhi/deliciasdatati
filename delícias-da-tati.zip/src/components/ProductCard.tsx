import React, { useState } from 'react';
import { Heart, Plus, ShoppingBag, MessageCircle, Check, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { STORE_CONFIG } from '../data/products';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isFavorite,
  onToggleFavorite,
  onAddToCart,
  onSelectProduct,
}) => {
  const [addedAnimation, setAddedAnimation] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, 1);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(product.id);
  };

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    const message = encodeURIComponent(
      `Olá Tati! Gostaria de pedir "${product.name}" (${product.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}${product.priceUnit || ''}) do cardápio da Delícias da Tati.`
    );
    window.open(`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${message}`, '_blank');
  };

  const formattedPrice = product.price.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group relative bg-white rounded-2xl border border-[#EADBCE] hover:border-[#8C384F]/40 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden cursor-pointer transform hover:-translate-y-1"
    >
      {/* Top Image Container */}
      <div className="relative aspect-4/3 overflow-hidden bg-[#F6ECE4]">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          onError={(e) => {
            const target = e.currentTarget;
            target.onerror = null;
            target.src = 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80';
          }}
          className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500 ease-out"
        />
        
        {/* Subtle top vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />

        {/* Highlight Badge */}
        {product.highlightBadge && (
          <div className="absolute top-2.5 left-2.5 bg-gradient-to-r from-[#8C384F] to-[#71283B] text-white text-[11px] font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1 border border-white/20">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>{product.highlightBadge}</span>
          </div>
        )}

        {/* Top Right Action Icons: Favorite & WhatsApp Direct */}
        <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5 z-10">
          <button
            onClick={handleFavorite}
            aria-label={isFavorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
            className={`w-8 h-8 rounded-full flex items-center justify-center backdrop-blur-md transition-all duration-200 cursor-pointer ${
              isFavorite
                ? 'bg-rose-500 text-white shadow-md scale-105'
                : 'bg-white/85 text-[#542B20] hover:bg-white hover:text-rose-500 shadow-xs'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
          </button>

          <button
            onClick={handleWhatsApp}
            aria-label={`Pedir ${product.name} no WhatsApp`}
            title="Pedir direto no WhatsApp"
            className="w-8 h-8 rounded-full bg-white/85 hover:bg-emerald-500 text-[#0F6F37] hover:text-white backdrop-blur-md shadow-xs flex items-center justify-center transition-all duration-200 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[11px] font-semibold text-[#8C384F] tracking-wide uppercase block mb-1">
            {product.categoryLabel}
          </span>
          <h3 className="font-serif-title font-bold text-base sm:text-lg text-[#2E140C] group-hover:text-[#8C384F] transition-colors leading-snug line-clamp-1 mb-1.5">
            {product.name}
          </h3>
          <p className="text-xs sm:text-[13px] text-[#715045] leading-relaxed line-clamp-2 mb-3">
            {product.description}
          </p>

          {/* If Kit, highlight items count */}
          {product.contents && (
            <div className="mb-3 py-1.5 px-2 bg-[#FAF3EE] rounded-lg border border-[#EDE0D6] text-[11px] text-[#6A473D]">
              <span className="font-semibold text-[#8C384F]">Inclui: </span>
              {product.contents[0]} e muito mais!
            </div>
          )}
        </div>

        {/* Price & Add to Cart Action */}
        <div className="pt-3 border-t border-[#F0E2D8] flex items-center justify-between gap-2 mt-auto">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#8C6457] block">
              Preço
            </span>
            <div className="flex items-baseline gap-0.5">
              <span className="text-base sm:text-lg font-extrabold text-[#38160E]">
                {formattedPrice}
              </span>
              {product.priceUnit && (
                <span className="text-xs font-semibold text-[#7D5347]">
                  {product.priceUnit}
                </span>
              )}
            </div>
          </div>

          <button
            onClick={handleAdd}
            aria-label={`Adicionar ${product.name} ao carrinho`}
            className={`flex items-center gap-1.5 px-3.5 sm:px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all duration-200 shadow-sm cursor-pointer active:scale-95 ${
              addedAnimation
                ? 'bg-emerald-600 text-white scale-102'
                : 'bg-gradient-to-r from-[#8C384F] to-[#71283B] hover:from-[#9D3D58] hover:to-[#812B41] text-white hover:shadow-md'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-4 h-4" />
                <span>Adicionado!</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span className="hidden xs:inline">Adicionar</span>
                <ShoppingBag className="w-4 h-4 xs:hidden" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
