import React, { useState } from 'react';
import { X, User, Save, CheckCircle2, MapPin, Phone, Heart, ShoppingBag } from 'lucide-react';
import { CustomerInfo } from '../types';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerInfo: CustomerInfo;
  onSaveCustomerInfo: (info: CustomerInfo) => void;
  favoritesCount: number;
  cartCount: number;
}

export const AccountModal: React.FC<AccountModalProps> = ({
  isOpen,
  onClose,
  customerInfo,
  onSaveCustomerInfo,
  favoritesCount,
  cartCount,
}) => {
  const [formData, setFormData] = useState<CustomerInfo>(customerInfo);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveCustomerInfo(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#FFFDF9] rounded-2xl max-w-md w-full shadow-2xl border border-[#E0CFBF] overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#EEDDD4] bg-[#FAF2EB] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#8C384F] text-white flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif-title font-bold text-lg text-[#30150D]">
                Minha Conta & Dados
              </h3>
              <span className="text-xs text-[#8C5D4E]">
                Seus dados salvos no navegador para pedidos rápidos
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white text-gray-500 hover:text-gray-800 flex items-center justify-center border border-[#DECBC0] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stats Badges */}
        <div className="grid grid-cols-2 gap-3 p-4 bg-[#FAF4EE] border-b border-[#EEDDD4]">
          <div className="bg-white p-2.5 rounded-xl border border-[#E6D6CA] flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
              <Heart className="w-4 h-4 fill-current" />
            </div>
            <div>
              <span className="text-xs text-[#7A5449] block">Favoritos</span>
              <span className="text-sm font-bold text-[#30150D]">{favoritesCount} salvos</span>
            </div>
          </div>

          <div className="bg-white p-2.5 rounded-xl border border-[#E6D6CA] flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs text-[#7A5449] block">No Carrinho</span>
              <span className="text-sm font-bold text-[#30150D]">{cartCount} itens</span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-[#442017] mb-1">
              Nome Completo
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Como prefere ser chamado(a)?"
              className="w-full text-sm px-3.5 py-2 rounded-xl border border-[#DECBC0] bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#442017] mb-1">
              WhatsApp
            </label>
            <div className="relative">
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(22) 99999-9999"
                className="w-full text-sm px-3.5 py-2 pl-9 rounded-xl border border-[#DECBC0] bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20"
              />
              <Phone className="w-4 h-4 text-[#8C5D4E] absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#442017] mb-1">
              Endereço de Entrega Principal
            </label>
            <div className="relative">
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Rua, número e complemento"
                className="w-full text-sm px-3.5 py-2 pl-9 rounded-xl border border-[#DECBC0] bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20"
              />
              <MapPin className="w-4 h-4 text-[#8C5D4E] absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-[#442017] mb-1">
                Bairro
              </label>
              <input
                type="text"
                value={formData.neighborhood}
                onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                placeholder="Tamoios"
                className="w-full text-sm px-3.5 py-2 rounded-xl border border-[#DECBC0] bg-white focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#442017] mb-1">
                Cidade
              </label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                placeholder="Cabo Frio/RJ"
                className="w-full text-sm px-3.5 py-2 rounded-xl border border-[#DECBC0] bg-white focus:outline-none"
              />
            </div>
          </div>

          {savedSuccess && (
            <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
              <span>Dados salvos com sucesso no seu dispositivo!</span>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              className="w-full bg-[#8C384F] hover:bg-[#72273B] text-white font-bold py-2.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Salvar Meus Dados</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
