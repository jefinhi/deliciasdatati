import React from 'react';
import { Heart, Sparkles, Award, ChefHat, Check } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="section-sobre" className="py-14 sm:py-20 bg-[#FFFDF9] border-b border-[#EADBCE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-center">
          
          {/* Left: Image Montage */}
          <div className="relative">
            <div className="aspect-4/3 rounded-3xl overflow-hidden shadow-2xl border-4 border-[#FAF3EE] relative">
              <img
                src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1000&q=80"
                alt="Confeitaria Delícias da Tati"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
            </div>

            {/* Floating badge */}
            <div className="absolute -bottom-6 -right-3 sm:right-6 bg-white p-4 sm:p-5 rounded-2xl shadow-xl border border-[#E8D6C9] max-w-[240px]">
              <div className="flex items-center gap-2 mb-1 text-[#8C384F]">
                <Award className="w-5 h-5 text-amber-500" />
                <span className="font-bold text-xs uppercase tracking-wider">Qualidade Artesanal</span>
              </div>
              <p className="text-xs text-[#6A473D] leading-snug">
                Receitas autorais e carinho em cada detalhe da sua encomenda.
              </p>
            </div>
          </div>

          {/* Right: Story & Mission */}
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FAF0E8] text-[#8C384F] text-xs font-bold uppercase tracking-wider mb-3 border border-[#EADBCE]">
              <Heart className="w-3.5 h-3.5 fill-[#8C384F]" />
              <span>Nossa História</span>
            </div>

            <h2 className="font-serif-title text-3xl sm:text-4xl font-bold text-[#32160E] leading-tight mb-4">
              Feito com amor para você
            </h2>

            <div className="space-y-3.5 text-sm sm:text-base text-[#6E493E] leading-relaxed mb-6">
              <p>
                A <strong className="text-[#32160E]">Delícias da Tati</strong> nasceu para transformar momentos simples em momentos especiais.
              </p>
              <p>
                Cada doce, bolo, salgado e produto é preparado com carinho, cuidado e ingredientes selecionados de alta qualidade.
              </p>
              <p>
                Nossa missão é oferecer sabor, qualidade e uma experiência especial em cada pedido que chega à mesa da sua família e amigos.
              </p>
            </div>

            {/* Quality check points */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#EEDDD4]">
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#422016]">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <span>Ingredientes 100% nobres</span>
              </div>

              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#422016]">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <span>Preparo diário e sob encomenda</span>
              </div>

              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#422016]">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <span>Embalagens seguras e elegantes</span>
              </div>

              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#422016]">
                <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
                <span>Atendimento humanizado e rápido</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
