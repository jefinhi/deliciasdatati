import React, { useState } from 'react';
import { Sparkles, MessageCircle, Calendar, Send, CheckCircle2 } from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

export const CustomOrderSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [productType, setProductType] = useState('Bolo Personalizado com Tema');
  const [quantity, setQuantity] = useState('');
  const [desiredDate, setDesiredDate] = useState('');
  const [notes, setNotes] = useState('');
  const [sentNotice, setSentNotice] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    const message = [
      '🍰 *PEDIDO PERSONALIZADO — DELÍCIAS DA TATI*',
      '',
      `*Nome:* ${name}`,
      `*WhatsApp:* ${phone}`,
      `*Tipo de Produto:* ${productType}`,
      `*Quantidade/Tamanho estimado:* ${quantity || 'A combinar'}`,
      `*Data desejada:* ${desiredDate || 'A combinar'}`,
      `*Observações/Tema:* ${notes || 'Sem observações'}`,
      '',
      'Gostaria de solicitar um orçamento personalizado!'
    ].join('\n');

    const url = `https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
    setSentNotice(true);
    setTimeout(() => setSentNotice(false), 4000);
  };

  return (
    <section id="personalizado" className="py-12 sm:py-16 bg-gradient-to-br from-[#FAF3EE] via-[#F8ECE2] to-[#FAF1E8] border-b border-[#EAD8CC]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-[#E8D4C8] relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-rose-100/40 rounded-full blur-3xl -z-0 pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto text-center mb-8">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF0E8] text-[#8C384F] text-xs font-bold uppercase tracking-wider mb-2 border border-[#E8D4C8]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Encomendas Especiais</span>
            </div>
            <h2 className="font-serif-title text-2xl sm:text-3xl lg:text-4xl font-bold text-[#32160E] mb-2">
              Quer um pedido personalizado?
            </h2>
            <p className="text-xs sm:text-sm text-[#734F44] leading-relaxed">
              Fazemos bolos temáticos, kits corporativos, festas completas e encomendas especiais sob medida para sua data inesquecível.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
            <div>
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Seu Nome *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Mariana Castro"
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Seu WhatsApp *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Ex: (22) 99896-5437"
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Tipo de Produto Desejado
              </label>
              <select
                value={productType}
                onChange={(e) => setProductType(e.target.value)}
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F] text-[#361A12]"
              >
                <option value="Bolo Confeitado Temático">Bolo Confeitado Temático</option>
                <option value="Bolo de Casamento / Bodas">Bolo de Casamento / Bodas</option>
                <option value="Kit Festa Personalizado">Kit Festa Personalizado</option>
                <option value="Cento de Doces Finos">Cento de Doces Finos</option>
                <option value="Cento de Salgados de Festa">Cento de Salgados de Festa</option>
                <option value="Torta Salgada Decorada">Torta Salgada Decorada</option>
                <option value="Mesa Completa de Festa (Bolo + Doces + Salgados)">Mesa Completa de Festa (Bolo + Doces + Salgados)</option>
                <option value="Outro pedido exclusivo">Outro pedido exclusivo</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Quantidade ou Tamanho Aproximado
              </label>
              <input
                type="text"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                placeholder="Ex: Bolo para 25 pessoas ou 150 salgados"
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F]"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Data Desejada do Evento
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={desiredDate}
                  onChange={(e) => setDesiredDate(e.target.value)}
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F] text-[#361A12]"
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-[#48251C] mb-1">
                Observações, Detalhes e Preferências de Sabores
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Conte-nos como imagina: cores, tema da decoração, recheios preferidos, etc."
                className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#DECBC0] bg-[#FFFDF9] focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 focus:border-[#8C384F]"
              />
            </div>

            {sentNotice && (
              <div className="sm:col-span-2 flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Seu pedido foi formatado e o WhatsApp foi aberto para envio!</span>
              </div>
            )}

            <div className="sm:col-span-2 pt-2">
              <button
                type="submit"
                className="w-full bg-[#128C45] hover:bg-[#16A250] text-white font-bold py-3.5 px-6 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 text-sm sm:text-base cursor-pointer border border-emerald-600/40 active:scale-98"
              >
                <MessageCircle className="w-5 h-5 fill-white" />
                <span>QUERO FAZER UM PEDIDO</span>
              </button>
            </div>
          </form>

        </div>

      </div>
    </section>
  );
};
