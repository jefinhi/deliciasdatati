import React from 'react';
import { MessageCircle } from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

export const FloatingWhatsApp: React.FC = () => {
  const message = encodeURIComponent(
    'Olá! Gostaria de falar com o atendimento da Delícias da Tati.'
  );

  return (
    <aside aria-label="Atendimento rápido" className="fixed bottom-5 right-5 z-40">
      <a
        id="btn-whatsapp-floating"
        href={`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${message}`}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2.5 bg-[#128C45] hover:bg-[#16A250] text-white px-4 py-3 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 active:scale-95 animate-pulse-subtle border-2 border-white/40 cursor-pointer"
        aria-label="Fale Conosco pelo WhatsApp"
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6 fill-white" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-300 animate-ping"></span>
        </div>
        <span className="font-bold text-sm tracking-wide hidden sm:inline">
          Fale Conosco
        </span>
      </a>
    </aside>
  );
};
