import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Utensils, MessageCircle, Sparkles, Award, Heart } from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

interface HeroBannerProps {
  onExploreMenu: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onExploreMenu }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      title: 'Delícias da Tati',
      subtitle: 'Bolos confeitados, doces finos, salgados de festa e kits completos!',
      description: 'Feitos com ingredientes selecionados, muito amor e aquele sabor inesquecível para suas comemorações.',
      tag: 'Confeitaria Artesanal de Festas & Delivery',
      image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1600&q=85',
      badge: 'Bolo Supremo de Chocolate com Morangos e Brigadeiros',
    },
    {
      id: 2,
      title: 'Salgadinhos de Festa',
      subtitle: 'Crocância dourada, sequinhos e recheios generosos!',
      description: 'Coxinhas premiadas, risoles cremosos, kibes recheados, empadas e centos de salgados para festas e aniversários.',
      tag: 'Fritos & Assados na Hora',
      image: 'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=1600&q=85',
      badge: 'Centos de Salgados para Festas & Eventos',
    },
    {
      id: 3,
      title: 'Kits Festas & Celebrações',
      subtitle: 'Sua festa completa, prática e inesquecível!',
      description: 'Combinações com bolo personalizado, salgadinhos crocantes, docinhos finos e refrigerantes gelados.',
      tag: 'Praticidade com Padrão Gourmet',
      image: 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?auto=format&fit=crop&w=1600&q=85',
      badge: 'Kits a partir de R$ 129,90 com Entrega em Cabo Frio',
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const active = slides[currentSlide];

  return (
    <section id="hero" className="relative bg-[#20100A] text-white overflow-hidden">
      {/* Background Image Carousel with Dark Gradient Overlay */}
      <div className="relative min-h-[520px] sm:min-h-[560px] lg:min-h-[600px] flex items-center">
        {slides.map((slide, idx) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              idx === currentSlide ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-7000 ease-out"
            />
            {/* Rich multi-stop gradient for readable typography without losing food appetite appeal */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#1E0E08]/95 via-[#2A140D]/80 to-[#1E0E08]/60" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#20100A] via-transparent to-black/30" />
          </div>
        ))}

        {/* Hero Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 w-full">
          <div className="max-w-2xl">
            {/* Pill badge */}
            <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-300/40 text-amber-200 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase mb-4 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{active.tag}</span>
            </div>

            {/* Main Headings */}
            <h1 className="font-serif-title text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-3 leading-tight drop-shadow-md">
              {active.title}
            </h1>

            <p className="text-lg sm:text-xl font-medium text-rose-200 mb-3 drop-shadow-sm">
              {active.subtitle}
            </p>

            <p className="text-sm sm:text-base text-[#E5CBC3] leading-relaxed mb-8 max-w-xl">
              {active.description}
            </p>

            {/* Interactive Call-to-Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onExploreMenu}
                className="bg-gradient-to-r from-[#B03A56] to-[#8C2840] hover:from-[#C04260] hover:to-[#9B2F48] text-white font-bold px-7 py-3.5 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2.5 text-sm sm:text-base cursor-pointer border border-[#E07991]/30"
              >
                <Utensils className="w-4 h-4" />
                <span>VER CARDÁPIO</span>
              </button>

              <a
                href={`https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent('Olá Tati! Vi o cardápio e gostaria de fazer um pedido especial.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#128C45] hover:bg-[#16A250] text-white font-bold px-6 py-3.5 rounded-full shadow-md hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 flex items-center gap-2 text-sm sm:text-base border border-emerald-400/40"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>PEDIR PELO WHATSAPP</span>
              </a>
            </div>

            {/* Micro Highlights */}
            <div className="mt-8 pt-6 border-t border-white/15 flex flex-wrap items-center gap-4 sm:gap-6 text-xs text-[#E6CFC7]">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-300" />
                <span>Ingredientes Selecionados & Frescos</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />
                <span>Feito com Amor & Cuidado</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Entrega Rápida em Tamoios/Cabo Frio</span>
              </div>
            </div>

          </div>
        </div>

        {/* Carousel Prev/Next Controls */}
        <button
          onClick={() => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)}
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 transition-all cursor-pointer"
          aria-label="Slide anterior"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-xs border border-white/20 transition-all cursor-pointer"
          aria-label="Próximo slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Carousel Dots indicator */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                i === currentSlide ? 'w-8 bg-amber-300' : 'w-2 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
