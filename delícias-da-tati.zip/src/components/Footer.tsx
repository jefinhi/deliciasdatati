import React from 'react';
import { Cake, Phone, MapPin, Clock, Heart, Instagram, Facebook, MessageCircle, ArrowUp } from 'lucide-react';
import { STORE_CONFIG } from '../data/products';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const menuLinks = [
    { label: 'Início', target: 'hero' },
    { label: 'Doces de Festa', target: 'section-doces' },
    { label: 'Bolos Confeitados', target: 'section-bolos' },
    { label: 'Salgados de Festa', target: 'section-salgados' },
    { label: 'Mousses & Sobremesas', target: 'section-mousses' },
    { label: 'Kits Festas Completos', target: 'section-kits' },
    { label: 'Encomendas Especiais', target: 'personalizado' },
    { label: 'Sobre a Delícias da Tati', target: 'section-sobre' },
    { label: 'Localização & Contato', target: 'section-contato' },
  ];

  const handleLinkClick = (target: string) => {
    const el = document.getElementById(target);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      scrollToTop();
    }
  };

  return (
    <footer className="bg-[#1C0E08] text-[#E8D4C8] pt-14 pb-8 border-t border-[#381B12]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10 pb-12 border-b border-[#361910]">
          
          {/* Col 1: Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#8C384F] to-[#541D29] text-amber-200 flex items-center justify-center border border-amber-300/40 shadow-md">
                <Cake className="w-6 h-6 text-amber-200" />
              </div>
              <div>
                <h3 className="font-serif-title font-bold text-xl text-white tracking-wide">
                  {STORE_CONFIG.name}
                </h3>
                <span className="text-xs text-rose-300 font-medium block">
                  {STORE_CONFIG.slogan}
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#CDB2A6] leading-relaxed">
              Bolos confeitados, doces finos, salgados de festa, mousses e kits completos preparados com ingredientes selecionados, muito amor e aquele sabor inesquecível.
            </p>

            {/* Social icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href={`https://wa.me/${STORE_CONFIG.whatsappRaw}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#2E160E] hover:bg-[#128C45] text-white flex items-center justify-center transition-colors border border-[#4A2418]"
                aria-label="WhatsApp da Delícias da Tati"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
              </a>

              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#2E160E] hover:bg-[#E1306C] text-white flex items-center justify-center transition-colors border border-[#4A2418]"
                aria-label="Instagram da Delícias da Tati"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#2E160E] hover:bg-[#1877F2] text-white flex items-center justify-center transition-colors border border-[#4A2418]"
                aria-label="Facebook da Delícias da Tati"
              >
                <Facebook className="w-4 h-4 fill-white" />
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div>
            <h4 className="font-serif-title font-bold text-base text-white mb-4 pb-1.5 border-b border-[#361910] inline-block">
              Navegação Rápida
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {menuLinks.slice(0, 5).map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleLinkClick(link.target)}
                    className="hover:text-amber-200 transition-colors cursor-pointer text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Categories Links */}
          <div>
            <h4 className="font-serif-title font-bold text-base text-white mb-4 pb-1.5 border-b border-[#361910] inline-block">
              Cardápio Especial
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {menuLinks.slice(5).map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleLinkClick(link.target)}
                    className="hover:text-amber-200 transition-colors cursor-pointer text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact info */}
          <div className="space-y-3">
            <h4 className="font-serif-title font-bold text-base text-white mb-4 pb-1.5 border-b border-[#361910] inline-block">
              Fale Conosco
            </h4>

            <div className="flex items-start gap-2.5 text-xs sm:text-sm text-[#D8BDB2]">
              <MapPin className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
              <span>{STORE_CONFIG.address}</span>
            </div>

            <div className="flex items-center gap-2.5 text-xs sm:text-sm text-[#D8BDB2]">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <a
                href={`https://wa.me/${STORE_CONFIG.whatsappRaw}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-amber-200 transition-colors font-medium"
              >
                {STORE_CONFIG.whatsappDisplay}
              </a>
            </div>

            <div className="flex items-start gap-2.5 text-xs sm:text-sm text-[#D8BDB2]">
              <Clock className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" />
              <div>
                <span className="block">Segunda a Sábado: até 22h</span>
                <span className="block">Domingo: 8h às 18h</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={scrollToTop}
                className="inline-flex items-center gap-1.5 text-xs text-amber-200 hover:text-white transition-colors cursor-pointer"
              >
                <ArrowUp className="w-3.5 h-3.5" />
                <span>Voltar ao topo da página</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#9B776A]">
          <p>© 2026 Delícias da Tati. Todos os direitos reservados.</p>
          <p className="flex items-center gap-1">
            <span>Sabor em cada detalhe feito com</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 inline" />
            <span>em Tamoios, Cabo Frio/RJ</span>
          </p>
        </div>

      </div>
    </footer>
  );
};
