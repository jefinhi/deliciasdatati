import React, { useState } from 'react';
import { X, Check, Copy, MessageCircle, QrCode, CreditCard, Banknote, Truck, Store, AlertCircle } from 'lucide-react';
import { CartItem, CustomerInfo } from '../types';
import { STORE_CONFIG } from '../data/products';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  customerInfo: CustomerInfo;
  onUpdateCustomerInfo: (info: CustomerInfo) => void;
  onOrderCompleted: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  customerInfo,
  onUpdateCustomerInfo,
  onOrderCompleted,
}) => {
  const [copiedPix, setCopiedPix] = useState(false);
  const [showErrors, setShowErrors] = useState(false);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  const deliveryFee =
    customerInfo.deliveryType === 'pickup'
      ? 0
      : subtotal >= STORE_CONFIG.freeDeliveryThreshold
      ? 0
      : STORE_CONFIG.deliveryFee;

  const total = subtotal + deliveryFee;

  const formatCurrency = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const handleCopyPix = () => {
    navigator.clipboard.writeText(STORE_CONFIG.pixKey);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2500);
  };

  const validateAndSubmit = () => {
    if (!customerInfo.name.trim() || !customerInfo.phone.trim()) {
      setShowErrors(true);
      return;
    }
    if (customerInfo.deliveryType === 'delivery' && !customerInfo.address.trim()) {
      setShowErrors(true);
      return;
    }

    // Build the formatted WhatsApp message strictly per user requirements
    const itemsText = cartItems
      .map(
        (item) =>
          `• ${item.quantity}x ${item.product.name} — ${formatCurrency(
            item.product.price * item.quantity
          )}`
      )
      .join('\n');

    const paymentLabel =
      customerInfo.paymentMethod === 'pix'
        ? 'PIX'
        : customerInfo.paymentMethod === 'cartao_entrega'
        ? 'Cartão (Débito/Crédito na entrega)'
        : `Dinheiro ${customerInfo.changeFor ? `(Troco para ${customerInfo.changeFor})` : '(Sem troco)'}`;

    const deliveryDetail =
      customerInfo.deliveryType === 'delivery'
        ? `Entrega no endereço: ${customerInfo.address}, ${customerInfo.neighborhood || 'Tamoios'} - ${customerInfo.city || 'Cabo Frio/RJ'}`
        : 'Retirada no balcão (Rua do Sol, Tamoios)';

    const message = [
      'Olá! Gostaria de fazer um pedido:',
      '',
      itemsText,
      '',
      `Subtotal: ${formatCurrency(subtotal)}`,
      `Taxa de Entrega: ${deliveryFee === 0 ? 'Grátis' : formatCurrency(deliveryFee)}`,
      `Total: ${formatCurrency(total)}`,
      '',
      `*Cliente:* ${customerInfo.name}`,
      `*Contato:* ${customerInfo.phone}`,
      `*Recebimento:* ${deliveryDetail}`,
      `*Forma de Pagamento:* ${paymentLabel}`,
      '',
      'Gostaria de confirmar meu pedido.'
    ].join('\n');

    const url = `https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
    onOrderCompleted();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#FFFDF9] rounded-2xl max-w-lg w-full shadow-2xl border border-[#E0CFBF] overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#EEDDD4] bg-[#FAF2EB] flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-serif-title font-bold text-xl text-[#30150D]">
              Finalizar Pedido
            </h3>
            <span className="text-xs text-[#8C5D4E]">
              Preencha seus dados para confirmação automática no WhatsApp
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white text-gray-500 hover:text-gray-800 flex items-center justify-center border border-[#DECBC0] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Order quick summary */}
          <div className="bg-[#FAF4EE] p-3.5 rounded-xl border border-[#E8D9CD]">
            <div className="text-xs font-bold uppercase text-[#8C384F] tracking-wide mb-2 flex justify-between">
              <span>Resumo dos Itens ({cartItems.length})</span>
              <span>{formatCurrency(total)}</span>
            </div>
            <div className="max-h-28 overflow-y-auto space-y-1 text-xs text-[#523026]">
              {cartItems.map((it) => (
                <div key={it.product.id} className="flex justify-between">
                  <span className="truncate pr-2">{it.quantity}x {it.product.name}</span>
                  <span className="font-medium shrink-0">{formatCurrency(it.product.price * it.quantity)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery or Pickup selection */}
          <div>
            <label className="block text-xs font-bold text-[#442017] uppercase tracking-wider mb-1.5">
              Forma de Recebimento
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onUpdateCustomerInfo({ ...customerInfo, deliveryType: 'delivery' })}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  customerInfo.deliveryType === 'delivery'
                    ? 'bg-[#8C384F] text-white border-[#8C384F] shadow-xs'
                    : 'bg-white text-[#522D22] border-[#DCCAC0] hover:bg-[#F9EEE7]'
                }`}
              >
                <Truck className="w-4 h-4" />
                <span>Delivery / Entrega</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateCustomerInfo({ ...customerInfo, deliveryType: 'pickup' })}
                className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  customerInfo.deliveryType === 'pickup'
                    ? 'bg-[#8C384F] text-white border-[#8C384F] shadow-xs'
                    : 'bg-white text-[#522D22] border-[#DCCAC0] hover:bg-[#F9EEE7]'
                }`}
              >
                <Store className="w-4 h-4" />
                <span>Retirada no Local</span>
              </button>
            </div>
          </div>

          {/* Customer info fields */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-[#442017] mb-1">
                Seu Nome Completo *
              </label>
              <input
                type="text"
                value={customerInfo.name}
                onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, name: e.target.value })}
                placeholder="Ex: Amanda Silva"
                className={`w-full text-sm px-3.5 py-2.5 rounded-xl border bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 ${
                  showErrors && !customerInfo.name.trim()
                    ? 'border-red-500 bg-red-50/20'
                    : 'border-[#DECBC0]'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#442017] mb-1">
                WhatsApp com DDD *
              </label>
              <input
                type="tel"
                value={customerInfo.phone}
                onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, phone: e.target.value })}
                placeholder="Ex: (22) 99896-5437"
                className={`w-full text-sm px-3.5 py-2.5 rounded-xl border bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 ${
                  showErrors && !customerInfo.phone.trim()
                    ? 'border-red-500 bg-red-50/20'
                    : 'border-[#DECBC0]'
                }`}
              />
            </div>

            {customerInfo.deliveryType === 'delivery' && (
              <>
                <div>
                  <label className="block text-xs font-semibold text-[#442017] mb-1">
                    Endereço Completo com Número *
                  </label>
                  <input
                    type="text"
                    value={customerInfo.address}
                    onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, address: e.target.value })}
                    placeholder="Ex: Rua do Sol, nº 120, apto 201"
                    className={`w-full text-sm px-3.5 py-2.5 rounded-xl border bg-white focus:outline-none focus:ring-2 focus:ring-[#8C384F]/20 ${
                      showErrors && !customerInfo.address.trim()
                        ? 'border-red-500 bg-red-50/20'
                        : 'border-[#DECBC0]'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-[#442017] mb-1">
                      Bairro
                    </label>
                    <input
                      type="text"
                      value={customerInfo.neighborhood}
                      onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, neighborhood: e.target.value })}
                      placeholder="Ex: Tamoios"
                      className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-[#DECBC0] bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#442017] mb-1">
                      Cidade
                    </label>
                    <input
                      type="text"
                      value={customerInfo.city}
                      onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, city: e.target.value })}
                      placeholder="Cabo Frio / RJ"
                      className="w-full text-sm px-3.5 py-2.5 rounded-xl border border-[#DECBC0] bg-white focus:outline-none"
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-bold text-[#442017] uppercase tracking-wider mb-1.5">
              Forma de Pagamento
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => onUpdateCustomerInfo({ ...customerInfo, paymentMethod: 'pix' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                  customerInfo.paymentMethod === 'pix'
                    ? 'bg-[#EBF7F0] border-emerald-600 text-emerald-800 shadow-xs'
                    : 'bg-white border-[#DECBC0] text-[#522D22] hover:bg-[#F9EEE7]'
                }`}
              >
                <QrCode className="w-4 h-4 text-emerald-600" />
                <span>PIX</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateCustomerInfo({ ...customerInfo, paymentMethod: 'cartao_entrega' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                  customerInfo.paymentMethod === 'cartao_entrega'
                    ? 'bg-[#F9EBEF] border-[#8C384F] text-[#8C384F] shadow-xs'
                    : 'bg-white border-[#DECBC0] text-[#522D22] hover:bg-[#F9EEE7]'
                }`}
              >
                <CreditCard className="w-4 h-4 text-[#8C384F]" />
                <span>Cartão</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateCustomerInfo({ ...customerInfo, paymentMethod: 'dinheiro' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                  customerInfo.paymentMethod === 'dinheiro'
                    ? 'bg-[#FFF8E7] border-amber-600 text-amber-900 shadow-xs'
                    : 'bg-white border-[#DECBC0] text-[#522D22] hover:bg-[#F9EEE7]'
                }`}
              >
                <Banknote className="w-4 h-4 text-amber-600" />
                <span>Dinheiro</span>
              </button>
            </div>

            {/* PIX Details Box */}
            {customerInfo.paymentMethod === 'pix' && (
              <div className="mt-3 p-3.5 bg-[#F2FAF5] rounded-xl border border-[#C5E8D2] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-800">Chave PIX (E-mail):</span>
                  <span className="text-[11px] text-emerald-700">Aprovação imediata</span>
                </div>
                <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-[#C5E8D2]">
                  <span className="text-xs font-mono text-gray-800 truncate flex-1 font-semibold">
                    {STORE_CONFIG.pixKey}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyPix}
                    className="shrink-0 flex items-center gap-1 text-xs bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer"
                  >
                    {copiedPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPix ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-[#2F6543] leading-tight">
                  Após copiar e pagar pelo seu banco, confirme enviando o comprovante no WhatsApp.
                </p>
              </div>
            )}

            {/* Cash change field */}
            {customerInfo.paymentMethod === 'dinheiro' && (
              <div className="mt-3">
                <label className="block text-xs font-semibold text-[#442017] mb-1">
                  Precisa de troco? Para quanto?
                </label>
                <input
                  type="text"
                  value={customerInfo.changeFor || ''}
                  onChange={(e) => onUpdateCustomerInfo({ ...customerInfo, changeFor: e.target.value })}
                  placeholder="Ex: Troco para R$ 100,00 ou Não preciso"
                  className="w-full text-sm px-3.5 py-2 rounded-xl border border-[#DECBC0] bg-white focus:outline-none"
                />
              </div>
            )}
          </div>

          {showErrors && (!customerInfo.name.trim() || !customerInfo.phone.trim() || (customerInfo.deliveryType === 'delivery' && !customerInfo.address.trim())) && (
            <div className="flex items-center gap-2 text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Por favor, preencha todos os campos obrigatórios marcados com asterisco.</span>
            </div>
          )}

        </div>

        {/* Footer actions */}
        <div className="p-4 sm:p-5 border-t border-[#EEDDD4] bg-[#FAF2EB] shrink-0 space-y-2">
          <div className="flex justify-between items-center text-sm font-bold text-[#30150D]">
            <span>Total a Pagar</span>
            <span className="text-lg text-[#8C384F]">{formatCurrency(total)}</span>
          </div>

          <button
            type="button"
            onClick={validateAndSubmit}
            className="w-full bg-[#128C45] hover:bg-[#16A350] text-white font-bold py-3 px-4 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 text-sm cursor-pointer border border-emerald-600"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>CONFIRMAR & ENVIAR NO WHATSAPP</span>
          </button>
        </div>

      </div>
    </div>
  );
};
