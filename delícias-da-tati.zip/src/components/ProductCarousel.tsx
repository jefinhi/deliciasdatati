import React, { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface ProductCarouselProps {
  id: string;
  title: string;
  subtitle?: string;
  icon?: string;
  products: Product[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onSelectProduct: (product: Product) => void;
}

export const ProductCarousel: React.FC<ProductCarouselProps> = ({
  id,
  title,
  subtitle,
  icon,
  products,
  favorites,
  onToggleFavorite,
  onAddToCart,
  onSelectProduct,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [activeIndex, setActiveIndex] = useState(0);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 15);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 15);

      const totalSegments = Math.max(1, Math.ceil((scrollWidth - clientWidth) / 320) + 1);
      const progress = scrollLeft / (scrollWidth - clientWidth || 1);
      const current = Math.min(totalSegments - 1, Math.round(progress * (totalSegments - 1)));
      setActiveIndex(current);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });
    window.addEventListener('resize', checkScroll);
    return () => {
      el.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, [products]);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const cardWidth = 320;
      const scrollAmount = direction === 'left' ? -cardWidth * 1.5 : cardWidth * 1.5;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  if (products.length === 0) return null;

  return (
    <section id={id} className="py-10 sm:py-14 border-b border-[#EBD9CF] scroll-mt-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6 sm:mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              {icon && <span className="text-xl">{icon}</span>}
              <span className="text-xs uppercase font-extrabold tracking-wider text-[#8C384F]">
                Seleção Artesanal
              </span>
            </div>
            <h2 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#2E140C]">
              {title}
            </h2>
            {subtitle && (
              <p className="text-xs sm:text-sm text-[#7D5245] mt-1 max-w-xl">
                {subtitle}
              </p>
            )}
          </div>

          {/* Netflix Style Page Indicators + Controls */}
          <div className="flex items-center gap-3">
            {/* Segmented Dashes */}
            <div className="hidden md:flex items-center gap-1.5 mr-2">
              {[0, 1, 2, 3].map((barIdx) => (
                <div
                  key={barIdx}
                  className={`h-1 rounded-full transition-all duration-300 ${
                    activeIndex === barIdx
                      ? 'w-6 bg-[#8C384F]'
                      : 'w-2.5 bg-[#E4D1C5]'
                  }`}
                />
              ))}
            </div>

            {/* Desktop Navigation Arrows */}
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={() => handleScroll('left')}
                disabled={!canScrollLeft}
                className={`w-9 h-9 rounded-full border border-[#DFCCC0] bg-white flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                  canScrollLeft
                    ? 'hover:bg-[#FAF0E8] text-[#3D1A10] active:scale-95'
                    : 'opacity-30 cursor-not-allowed text-[#B2998E]'
                }`}
                aria-label={`Rolar ${title} para esquerda`}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleScroll('right')}
                disabled={!canScrollRight}
                className={`w-9 h-9 rounded-full border border-[#DFCCC0] bg-white flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                  canScrollRight
                    ? 'hover:bg-[#FAF0E8] text-[#3D1A10] active:scale-95'
                    : 'opacity-30 cursor-not-allowed text-[#B2998E]'
                }`}
                aria-label={`Rolar ${title} para direita`}
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Carousel Container with Netflix Hover Side Paddles */}
        <div className="relative group">
          
          {/* Netflix Left Edge Paddle Overlay */}
          <button
            onClick={() => handleScroll('left')}
            className={`hidden sm:flex absolute left-0 top-0 bottom-4 z-20 w-12 items-center justify-center bg-gradient-to-r from-[#FFFDF9]/95 via-[#FFFDF9]/60 to-transparent transition-opacity duration-300 cursor-pointer ${
              canScrollLeft ? 'opacity-0 group-hover:opacity-100' : 'pointer-events-none opacity-0'
            }`}
            aria-label={`Rolar ${title} para esquerda`}
          >
            <div className="w-9 h-9 rounded-full bg-white/95 border border-[#DECBC0] text-[#422117] flex items-center justify-center hover:scale-110 hover:bg-[#8C384F] hover:text-white hover:border-[#8C384F] transition-all shadow-lg">
              <ChevronLeft className="w-5 h-5" />
            </div>
          </button>

          {/* Netflix Right Edge Paddle Overlay */}
          <button
            onClick={() => handleScroll('right')}
            className={`hidden sm:flex absolute right-0 top-0 bottom-4 z-20 w-12 items-center justify-center bg-gradient-to-l from-[#FFFDF9]/95 via-[#FFFDF9]/60 to-transparent transition-opacity duration-300 cursor-pointer ${
              canScrollRight ? 'opacity-0 group-hover:opacity-100' : 'pointer-events-none opacity-0'
            }`}
            aria-label={`Rolar ${title} para direita`}
          >
            <div className="w-9 h-9 rounded-full bg-white/95 border border-[#DECBC0] text-[#422117] flex items-center justify-center hover:scale-110 hover:bg-[#8C384F] hover:text-white hover:border-[#8C384F] transition-all shadow-lg">
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>

          {/* Scroll Track */}
          <div
            ref={scrollRef}
            className="flex gap-4 sm:gap-6 overflow-x-auto pb-4 pt-1 no-scrollbar snap-x snap-mandatory scroll-smooth"
          >
            {products.map((prod) => (
              <div
                key={prod.id}
                className="min-w-[260px] sm:min-w-[290px] max-w-[310px] shrink-0 snap-start"
              >
                <ProductCard
                  product={prod}
                  isFavorite={favorites.includes(prod.id)}
                  onToggleFavorite={onToggleFavorite}
                  onAddToCart={onAddToCart}
                  onSelectProduct={onSelectProduct}
                />
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
