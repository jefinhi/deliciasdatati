import React from 'react';
import { CATEGORIES } from '../data/products';

interface CategoryNavProps {
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  const handleCategoryClick = (catId: string) => {
    onSelectCategory(catId);
    if (catId === 'todos') {
      const el = document.getElementById('cardapio');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      const el = document.getElementById(`section-${catId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        const fallback = document.getElementById('cardapio');
        fallback?.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <section id="categorias" className="py-8 sm:py-10 bg-[#FAF4EF] border-b border-[#EAD8CE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-6 sm:mb-8">
          <span className="text-xs uppercase font-bold tracking-widest text-[#8C384F] block mb-1">
            Explore Nosso Cardápio
          </span>
          <h2 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#32160E]">
            Categorias Artesanais
          </h2>
          <p className="text-xs sm:text-sm text-[#7D5347] mt-1">
            Selecione uma categoria para conferir nossas receitas frescas feitas com muito carinho.
          </p>
        </div>

        {/* Categories Horizontal Scrolling Container with circular/pill cards */}
        <div className="flex items-center gap-3 sm:gap-5 overflow-x-auto pb-4 pt-1 no-scrollbar justify-start md:justify-center px-2">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                className={`group flex flex-col items-center shrink-0 p-2 sm:p-2.5 rounded-2xl transition-all duration-200 cursor-pointer text-center min-w-[84px] sm:min-w-[102px] ${
                  isSelected
                    ? 'bg-white shadow-md ring-2 ring-[#8C384F] scale-105'
                    : 'bg-white/70 hover:bg-white hover:shadow-sm hover:scale-102 border border-[#E9DACF]'
                }`}
                aria-label={`Ver categoria ${cat.label}`}
              >
                {/* Circular image badge with icon badge overlay */}
                <div className="relative w-14 h-14 sm:w-18 sm:h-18 rounded-full overflow-hidden mb-2 border-2 border-[#FAF4EF] shadow-xs group-hover:border-[#8C384F]/40 transition-colors">
                  <img
                    src={cat.image}
                    alt={cat.label}
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.onerror = null;
                      target.src = 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=400&q=80';
                    }}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-white/90 shadow-xs flex items-center justify-center text-xs">
                    {cat.icon}
                  </span>
                </div>

                <span className={`text-xs sm:text-sm font-bold block leading-tight ${
                  isSelected ? 'text-[#8C384F]' : 'text-[#361A12] group-hover:text-[#8C384F]'
                }`}>
                  {cat.label}
                </span>

                <span className="text-[10px] text-[#9A7367] mt-0.5 font-medium">
                  {cat.count} itens
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
