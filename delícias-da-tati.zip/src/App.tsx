import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryNav } from './components/CategoryNav';
import { ProductCarousel } from './components/ProductCarousel';
import { ProductCard } from './components/ProductCard';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { AccountModal } from './components/AccountModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CustomOrderSection } from './components/CustomOrderSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { AboutSection } from './components/AboutSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { PRODUCTS, STORE_CONFIG } from './data/products';
import { Product, CartItem, CustomerInfo } from './types';
import { Search, Heart, Sparkles, X, ShoppingBag } from 'lucide-react';

export default function App() {
  // Cart state persisted to localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('delicias_tati_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Favorites state persisted to localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('delicias_tati_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Customer info persisted to localStorage
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>(() => {
    try {
      const saved = localStorage.getItem('delicias_tati_customer');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      name: '',
      phone: '',
      address: '',
      neighborhood: 'Tamoios',
      city: 'Cabo Frio/RJ',
      deliveryType: 'delivery',
      paymentMethod: 'pix',
    };
  });

  // UI state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [deliveryType, setDeliveryType] = useState<'delivery' | 'pickup'>('delivery');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('delicias_tati_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('delicias_tati_favorites', JSON.stringify(favorites));
    } catch (e) {
      console.error('Failed to save favorites to localStorage', e);
    }
  }, [favorites]);

  useEffect(() => {
    try {
      localStorage.setItem('delicias_tati_customer', JSON.stringify(customerInfo));
    } catch (e) {
      console.error('Failed to save customer to localStorage', e);
    }
  }, [customerInfo]);

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });

    showToast(`"${product.name}" adicionado ao carrinho!`);
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removido do carrinho.');
  };

  const handleClearCart = () => {
    if (window.confirm('Tem certeza que deseja limpar todos os itens do carrinho?')) {
      setCart([]);
      showToast('Carrinho limpo.');
    }
  };

  // Favorites toggle
  const handleToggleFavorite = (productId: string) => {
    setFavorites((prev) => {
      if (prev.includes(productId)) {
        showToast('Removido dos favoritos.');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Adicionado aos favoritos!');
        return [...prev, productId];
      }
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2400);
  };

  // Cart totals
  const cartCount = useMemo(
    () => cart.reduce((acc, item) => acc + item.quantity, 0),
    [cart]
  );

  const cartTotal = useMemo(
    () => cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0),
    [cart]
  );

  // Filtered products for search or favorites
  const filteredProducts = useMemo(() => {
    let list = PRODUCTS;

    if (showOnlyFavorites) {
      list = list.filter((p) => favorites.includes(p.id));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.categoryLabel.toLowerCase().includes(q)
      );
    }

    return list;
  }, [searchQuery, showOnlyFavorites, favorites]);

  // Specific categorized lists for main carousels
  const docesProducts = useMemo(
    () => PRODUCTS.filter((p) => p.category === 'doces'),
    []
  );
  const bolosProducts = useMemo(
    () => PRODUCTS.filter((p) => p.category === 'bolos'),
    []
  );
  const salgadosProducts = useMemo(
    () => PRODUCTS.filter((p) => p.category === 'salgados'),
    []
  );
  const moussesProducts = useMemo(
    () => PRODUCTS.filter((p) => p.category === 'mousses'),
    []
  );
  const kitsProducts = useMemo(
    () => PRODUCTS.filter((p) => p.category === 'kits'),
    []
  );

  // Direct WhatsApp from Cart
  const handleSendDirectWhatsApp = () => {
    if (cart.length === 0) return;

    const subtotal = cartTotal;
    const deliveryFee =
      deliveryType === 'pickup'
        ? 0
        : subtotal >= STORE_CONFIG.freeDeliveryThreshold
        ? 0
        : STORE_CONFIG.deliveryFee;
    const total = subtotal + deliveryFee;

    const formatCurrency = (val: number) =>
      val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    const itemsText = cart
      .map(
        (item) =>
          `• ${item.quantity}x ${item.product.name} — ${formatCurrency(
            item.product.price * item.quantity
          )}`
      )
      .join('\n');

    const message = [
      'Olá! Gostaria de fazer um pedido:',
      '',
      itemsText,
      '',
      `Subtotal: ${formatCurrency(subtotal)}`,
      `Taxa de Entrega (${deliveryType === 'delivery' ? 'Tamoios' : 'Retirada'}): ${
        deliveryFee === 0 ? 'Grátis' : formatCurrency(deliveryFee)
      }`,
      `Total: ${formatCurrency(total)}`,
      '',
      customerInfo.name ? `*Nome:* ${customerInfo.name}` : '',
      customerInfo.phone ? `*WhatsApp:* ${customerInfo.phone}` : '',
      deliveryType === 'delivery' && customerInfo.address
        ? `*Endereço:* ${customerInfo.address}`
        : `*Forma de Recebimento:* ${deliveryType === 'delivery' ? 'Entrega em domicílio' : 'Retirada no balcão'}`,
      '',
      'Gostaria de confirmar meu pedido.'
    ]
      .filter(Boolean)
      .join('\n');

    window.open(
      `https://wa.me/${STORE_CONFIG.whatsappRaw}?text=${encodeURIComponent(message)}`,
      '_blank'
    );
  };

  const handleExploreMenu = () => {
    const el = document.getElementById('categorias');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF9] text-[#2E140C]">
      
      {/* Toast notification */}
      {toastMessage && (
        <aside
          aria-live="polite"
          aria-atomic="true"
          className="fixed top-20 right-4 z-50 bg-[#36160D] text-white text-xs sm:text-sm font-semibold px-4 py-3 rounded-2xl shadow-2xl border border-amber-300/30 flex items-center gap-2.5 animate-slideDown"
        >
          <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
          <span>{toastMessage}</span>
        </aside>
      )}

      {/* Main Header */}
      <Header
        cartCount={cartCount}
        cartTotal={cartTotal}
        favoritesCount={favorites.length}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        onToggleFavoritesOnly={() => setShowOnlyFavorites(!showOnlyFavorites)}
        showOnlyFavorites={showOnlyFavorites}
        onNavigateToCategory={(cat) => {
          setSelectedCategory(cat);
          setShowOnlyFavorites(false);
          setSearchQuery('');
        }}
        activeCategory={selectedCategory}
      />

      <main className="flex-1">
        {/* If user is searching or viewing favorites, show filtered grid */}
        {searchQuery.trim() || showOnlyFavorites ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            {/* Header for filtered view */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-[#EEDBCE]">
              <div>
                <span className="text-xs uppercase font-extrabold tracking-wider text-[#8C384F] block mb-1">
                  {showOnlyFavorites ? 'Seus Favoritos' : 'Busca no Cardápio'}
                </span>
                <h1 className="font-serif-title text-2xl sm:text-3xl font-bold text-[#2E140C]">
                  {showOnlyFavorites
                    ? 'Produtos que você favoritou'
                    : `Resultados para "${searchQuery}"`}
                </h1>
                <p className="text-xs sm:text-sm text-[#7F5346] mt-1">
                  {filteredProducts.length}{' '}
                  {filteredProducts.length === 1 ? 'produto encontrado' : 'produtos encontrados'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {showOnlyFavorites && (
                  <button
                    onClick={() => setShowOnlyFavorites(false)}
                    className="text-xs font-semibold px-4 py-2 rounded-xl bg-[#F6ECE4] hover:bg-[#EBDCCE] text-[#55271A] transition-colors cursor-pointer"
                  >
                    Ver todo o cardápio
                  </button>
                )}
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-xs font-semibold px-4 py-2 rounded-xl bg-[#8C384F] text-white hover:bg-[#72273B] transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Limpar pesquisa</span>
                  </button>
                )}
              </div>
            </div>

            {/* Filtered Grid or Empty State */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-[#FAF4EF] rounded-3xl border border-[#EADBCE] max-w-md mx-auto p-8">
                <div className="w-16 h-16 rounded-full bg-[#F3E5DC] text-[#8C384F] flex items-center justify-center mx-auto mb-4">
                  {showOnlyFavorites ? <Heart className="w-8 h-8" /> : <Search className="w-8 h-8" />}
                </div>
                <h3 className="font-serif-title text-xl font-bold text-[#32150E] mb-2">
                  {showOnlyFavorites
                    ? 'Nenhum favorito salvo ainda'
                    : 'Nenhum produto encontrado'}
                </h3>
                <p className="text-xs sm:text-sm text-[#7D5347] mb-6 leading-relaxed">
                  {showOnlyFavorites
                    ? 'Clique no ícone de coração em qualquer doce, bolo ou salgado para salvá-lo aqui.'
                    : 'Tente buscar por termos como "chocolate", "brigadeiro", "morango", "coxinha" ou "kit festa".'}
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setShowOnlyFavorites(false);
                  }}
                  className="bg-[#8C384F] hover:bg-[#72273B] text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-full transition-all shadow-md cursor-pointer"
                >
                  Limpar pesquisa e ver cardápio
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                {filteredProducts.map((prod) => (
                  <ProductCard
                    key={prod.id}
                    product={prod}
                    isFavorite={favorites.includes(prod.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onAddToCart={handleAddToCart}
                    onSelectProduct={setSelectedProduct}
                  />
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Standard Home View with All Sections per Prompt Requirements */
          <>
            {/* Hero / Banner Principal */}
            <HeroBanner onExploreMenu={handleExploreMenu} />

            {/* Categorias em formato circular / arredondado */}
            <CategoryNav
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => setSelectedCategory(cat)}
            />

            {/* Sections Anchor */}
            <div id="cardapio">
              {/* 1. Seção Doces */}
              <ProductCarousel
                id="section-doces"
                title="Doces em Destaque"
                subtitle="Brigadeiros gourmet, beijinhos, palhas italianas e doces finos feitos com puro cacau e afeto."
                icon="🍫"
                products={docesProducts}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                onAddToCart={handleAddToCart}
                onSelectProduct={setSelectedProduct}
              />

              {/* 2. Seção Bolos */}
              <ProductCarousel
                id="section-bolos"
                title="Bolos em Destaque"
                subtitle="Massa fofinha, recheios fartos e decorações exuberantes para transformar qualquer comemoração."
                icon="🎂"
                products={bolosProducts}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                onAddToCart={handleAddToCart}
                onSelectProduct={setSelectedProduct}
              />

              {/* 3. Seção Salgados */}
              <ProductCarousel
                id="section-salgados"
                title="Salgados de Festa"
                subtitle="Coxinhas ultracrocantes, risoles dourados, kibes recheados, tortas salgadas e centos de salgados para festas."
                icon="🥟"
                products={salgadosProducts}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                onAddToCart={handleAddToCart}
                onSelectProduct={setSelectedProduct}
              />

              {/* 4. Seção Mousses */}
              <ProductCarousel
                id="section-mousses"
                title="Mousses & Sobremesas"
                subtitle="Textura aerada, cremosidade inconfundível e o sabor puro e natural das frutas e chocolates nobres."
                icon="🍮"
                products={moussesProducts}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                onAddToCart={handleAddToCart}
                onSelectProduct={setSelectedProduct}
              />

              {/* 5. Seção Kits Festas */}
              <ProductCarousel
                id="section-kits"
                title="Kits Festas Completos"
                subtitle="Sua comemoração pronta com bolo, salgados quentinhos, doces finos e refrigerantes."
                icon="🎉"
                products={kitsProducts}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                onAddToCart={handleAddToCart}
                onSelectProduct={setSelectedProduct}
              />
            </div>

            {/* Custom Order Form ("Quer um pedido personalizado?") */}
            <CustomOrderSection />

            {/* Testimonials ("O que nossos clientes dizem") */}
            <TestimonialsSection />

            {/* About Section ("Feito com amor para você") */}
            <AboutSection />

            {/* Location & Opening Hours ("Nosso Endereço" & "Horário de Atendimento") */}
            <LocationSection />
          </>
        )}
      </main>

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onSendDirectWhatsApp={handleSendDirectWhatsApp}
        deliveryType={deliveryType}
        onDeliveryTypeChange={setDeliveryType}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cart}
        customerInfo={customerInfo}
        onUpdateCustomerInfo={setCustomerInfo}
        onOrderCompleted={() => {
          setCart([]);
          showToast('Pedido registrado e enviado para o WhatsApp!');
        }}
      />

      {/* Account / Saved Profile Modal */}
      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        customerInfo={customerInfo}
        onSaveCustomerInfo={(info) => {
          setCustomerInfo(info);
          showToast('Dados salvos com sucesso!');
        }}
        favoritesCount={favorites.length}
        cartCount={cartCount}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={selectedProduct !== null}
        onClose={() => setSelectedProduct(null)}
        isFavorite={selectedProduct ? favorites.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onAddToCart={handleAddToCart}
      />

      {/* Floating WhatsApp Button */}
      <FloatingWhatsApp />

      {/* Footer */}
      <Footer />

    </div>
  );
}
