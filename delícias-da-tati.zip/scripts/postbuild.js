import fs from 'fs';
import path from 'path';

const distIndexPath = path.resolve('dist', 'index.html');
const rootAbrirPath = path.resolve('abrir_site.html');

if (fs.existsSync(distIndexPath)) {
  let html = fs.readFileSync(distIndexPath, 'utf8');

  // Remove type="module" and crossorigin to prevent any file:// protocol CORS restrictions
  html = html.replace(/<script type="module" crossorigin>/g, '<script defer>');
  html = html.replace(/<script type="module">/g, '<script defer>');

  // Write back to dist/index.html
  fs.writeFileSync(distIndexPath, html, 'utf8');
  console.log('✔ Updated dist/index.html for universal file:// and web server compatibility');

  // Copy to root abrir_site.html for instant double-click access
  fs.writeFileSync(rootAbrirPath, html, 'utf8');
  console.log('✔ Generated root abrir_site.html for instant double-click opening');
}
