@echo off
title Abrindo Delicias da Tati...
echo =========================================
echo    Abrindo o site Delicias da Tati...
echo =========================================
if exist abrir_site.html (
    start abrir_site.html
) else if exist dist\index.html (
    start dist\index.html
) else (
    start index.html
)
exit
